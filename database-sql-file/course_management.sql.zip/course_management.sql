-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 09, 2025 at 05:02 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` bigint UNSIGNED NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title1_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title1_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description1_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description1_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature1_en` text COLLATE utf8mb4_unicode_ci,
  `feature1_bn` text COLLATE utf8mb4_unicode_ci,
  `feature2_en` text COLLATE utf8mb4_unicode_ci,
  `feature2_bn` text COLLATE utf8mb4_unicode_ci,
  `feature3_en` text COLLATE utf8mb4_unicode_ci,
  `feature3_bn` text COLLATE utf8mb4_unicode_ci,
  `feature4_en` text COLLATE utf8mb4_unicode_ci,
  `feature4_bn` text COLLATE utf8mb4_unicode_ci,
  `feature5_en` text COLLATE utf8mb4_unicode_ci,
  `feature5_bn` text COLLATE utf8mb4_unicode_ci,
  `feature6_en` text COLLATE utf8mb4_unicode_ci,
  `feature6_bn` text COLLATE utf8mb4_unicode_ci,
  `feature7_en` text COLLATE utf8mb4_unicode_ci,
  `feature7_bn` text COLLATE utf8mb4_unicode_ci,
  `feature8_en` text COLLATE utf8mb4_unicode_ci,
  `feature8_bn` text COLLATE utf8mb4_unicode_ci,
  `feature9_en` text COLLATE utf8mb4_unicode_ci,
  `feature9_bn` text COLLATE utf8mb4_unicode_ci,
  `feature10_en` text COLLATE utf8mb4_unicode_ci,
  `feature10_bn` text COLLATE utf8mb4_unicode_ci,
  `title2_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title2_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description2_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description2_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `footer_topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `title_en`, `title_bn`, `image1`, `image2`, `image3`, `image4`, `title1_en`, `title1_bn`, `description1_en`, `description1_bn`, `feature1_en`, `feature1_bn`, `feature2_en`, `feature2_bn`, `feature3_en`, `feature3_bn`, `feature4_en`, `feature4_bn`, `feature5_en`, `feature5_bn`, `feature6_en`, `feature6_bn`, `feature7_en`, `feature7_bn`, `feature8_en`, `feature8_bn`, `feature9_en`, `feature9_bn`, `feature10_en`, `feature10_bn`, `title2_en`, `title2_bn`, `description2_en`, `description2_bn`, `footer_topic1_en`, `footer_topic1_bn`, `footer_topic2_en`, `footer_topic2_bn`, `footer_topic3_en`, `footer_topic3_bn`, `footer_topic4_en`, `footer_topic4_bn`, `footer_topic5_en`, `footer_topic5_bn`, `footer_topic6_en`, `footer_topic6_bn`, `footer_topic7_en`, `footer_topic7_bn`, `footer_topic8_en`, `footer_topic8_bn`, `footer_topic9_en`, `footer_topic9_bn`, `footer_topic10_en`, `footer_topic10_bn`, `created_at`, `updated_at`) VALUES
(1, 'Honesty is the best policy.', 'সততাই সর্বোত্তম নীতি।', 'upload/about_us_images/1637896469.mission-man-1.svg', 'upload/about_us_images/490283858.mission-men-2.svg', 'upload/about_us_images/869542903.mission-man-3.svg', 'upload/about_us_images/2028179375.mission-man-4.svg', 'We are going to college.', 'আমরা কলেজে যাচ্ছি।', 'Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'ইপসাম প্যাসেজ, এবং আরও সাম্প্রতিক সময়ে ডেস্কটপ প্রকাশনা সফ্টওয়্যার যেমন Aldus PageMaker সহ Lorem Ipsum-এর সংস্করণ।', '<p>This is a feature</p>', '<p>এটি একটি বৈশিষ্ট্য</p>', '<p>This is a feature</p>', '<p>এটি একটি বৈশিষ্ট্য</p>', '<p>This is a feature</p>', '<p>এটি একটি বৈশিষ্ট্য</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'This is title two.', 'এই শিরোনাম দুই.', 'Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'ইপসাম প্যাসেজ, এবং আরও সাম্প্রতিক সময়ে ডেস্কটপ প্রকাশনা সফ্টওয়্যার যেমন Aldus PageMaker সহ Lorem Ipsum-এর সংস্করণ।', '<p>this is footer topic.</p>', '<p>এই ফুটার বিষয়.</p>', '<p>this is footer topic.</p>', '<p>এই ফুটার বিষয়.</p>', '<p>this is footer topic.</p>', '<p>এই ফুটার বিষয়.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-12-23 07:26:33', '2025-01-06 07:18:13');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint UNSIGNED NOT NULL,
  `blog_category_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image2` text COLLATE utf8mb4_unicode_ci,
  `video_url` text COLLATE utf8mb4_unicode_ci,
  `title2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content2_en` text COLLATE utf8mb4_unicode_ci,
  `content2_bn` text COLLATE utf8mb4_unicode_ci,
  `topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic5_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic5_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic6_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic6_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic7_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic7_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic8_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic8_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic9_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic9_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic10_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic10_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image3` text COLLATE utf8mb4_unicode_ci,
  `title3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content3_en` text COLLATE utf8mb4_unicode_ci,
  `content3_bn` text COLLATE utf8mb4_unicode_ci,
  `footer_topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_bn` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conclusiton_en` text COLLATE utf8mb4_unicode_ci,
  `conclusiton_bn` text COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '1',
  `is_featured` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `blog_category_id`, `user_id`, `title_en`, `title_bn`, `slug`, `image`, `content_en`, `content_bn`, `image2`, `video_url`, `title2_en`, `title2_bn`, `content2_en`, `content2_bn`, `topic1_en`, `topic1_bn`, `topic2_en`, `topic2_bn`, `topic3_en`, `topic3_bn`, `topic4_en`, `topic4_bn`, `topic5_en`, `topic5_bn`, `topic6_en`, `topic6_bn`, `topic7_en`, `topic7_bn`, `topic8_en`, `topic8_bn`, `topic9_en`, `topic9_bn`, `topic10_en`, `topic10_bn`, `image3`, `title3_en`, `title3_bn`, `content3_en`, `content3_bn`, `footer_topic1_en`, `footer_topic1_bn`, `footer_topic2_en`, `footer_topic2_bn`, `footer_topic3_en`, `footer_topic3_bn`, `footer_topic4_en`, `footer_topic4_bn`, `footer_topic5_en`, `footer_topic5_bn`, `footer_topic6_en`, `footer_topic6_bn`, `footer_topic7_en`, `footer_topic7_bn`, `footer_topic8_en`, `footer_topic8_bn`, `footer_topic9_en`, `footer_topic9_bn`, `footer_topic10_en`, `footer_topic10_bn`, `conclusiton_en`, `conclusiton_bn`, `status`, `is_featured`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 'Hadis is the second law source of Islam.', 'হাদিস হলো ইসলামী শরীয়াতের দ্বিতীয় উতস', 'hadis-is-the-second-source-law', 'upload/blog_images/619221895.blog-hadith.png', '<p>literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>সাহিত্য, সন্দেহাতীত উৎস আবিষ্কার করেছে। লোরেম ইপসাম 45 খ্রিস্টপূর্বাব্দে লেখা সিসেরোর \"ডি ফিনিবাস বোনোরাম এট ম্যালোরাম\" (দ্য এক্সট্রিমস অফ গুড অ্যান্ড ইভিল) এর বিভাগ 1.10.32 এবং 1.10.33 থেকে এসেছে। এই বইটি নৈতিকতার তত্ত্বের উপর একটি গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', 'upload/blog_images/1801978678.pc3.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'upload/blog_images/876286300.rose4.jpg', 'This is title three.', 'এই শিরোনাম তিন.', '<p>This is content three.This is content three.This is content three.This is content three.This is content three.This is content three.</p>', '<p>এই শিরোনাম তিন.এই শিরোনাম তিন.এই শিরোনাম তিন.এই শিরোনাম তিন.এই শিরোনাম তিন.এই শিরোনাম তিন.এই শিরোনাম তিন.</p>', '<p><strong>Footer1:</strong>This is footer topic one.</p>', '<p><strong>পাদচরণ 1</strong>: এটি পাদচরণ বিষয় এক.</p>', '<p><strong>Footer2:</strong>This is footer topic two.</p>', '<p><strong>পাদচরণ 2</strong>: এটি পাদচরণ বিষয় দুই.</p>', '<p><strong>Footer3:</strong>This is footer topic three.</p>', '<p><strong>পাদচরণ 3</strong>: এটি পাদচরণ বিষয় তিন.</p>', '<p><strong>Footer3:</strong>This is footer topic three.</p>', '<p><strong>পাদচরণ 3</strong>: এটি পাদচরণ বিষয় তিন.</p>', '<p><strong>Footer3:</strong>This is footer topic three.</p>', '<p><strong>পাদচরণ 3</strong>: এটি পাদচরণ বিষয় তিন.</p>', '<p><strong>Footer3:</strong>This is footer topic three.</p>', '<p><strong>পাদচরণ 3</strong>: এটি পাদচরণ বিষয় তিন.</p>', '<p><strong>Footer3:</strong>This is footer topic three.</p>', '<p><strong>পাদচরণ 3</strong>: এটি পাদচরণ বিষয় তিন.</p>', NULL, NULL, NULL, NULL, NULL, NULL, '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>45 খ্রিস্টপূর্বাব্দ। এই বইটি নৈতিকতার তত্ত্বের উপর একটি গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', 1, 0, '2024-12-20 09:24:36', '2025-01-05 06:23:24'),
(3, 3, 1, 'Ramadan is the month of quran revealed', 'রমজান মাস কুরান নাজিলের মাস', 'ramadan-revealed-quran', 'upload/blog_images/514263166.blog-hadith.png', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'upload/blog_images/127277472.blog1 - Copy.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'upload/blog_images/195433129.rose3 - Copy.jpg', 'This is title three.', 'এই শিরোনাম তিন.', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', NULL, NULL, '<p>structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>', '<p>যুক্তিসঙ্গত দেখায়। উত্পন্ন লোরেম ইপসাম তাই সবসময় পুনরাবৃত্তি, ইনজেকশন করা হাস্যরস, বা অ-চরিত্রহীন শব্দ ইত্যাদি থেকে মুক্ত।</p>', 1, 0, '2024-12-20 10:21:26', '2025-01-05 06:28:22'),
(6, 3, 1, 'Quran is mandatory for us', 'কুরান আমাদের জন্য আবশ্যক', 'quran-is-mandatory', 'upload/blog_images/1133577991.blog-hadith.png', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'upload/blog_images/127277472.blog1 - Copy.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'upload/blog_images/195433129.rose3 - Copy.jpg', 'This is title three.', 'এই শিরোনাম তিন.', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', NULL, NULL, '<p>structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>', '<p>যুক্তিসঙ্গত দেখায়। উত্পন্ন লোরেম ইপসাম তাই সবসময় পুনরাবৃত্তি, ইনজেকশন করা হাস্যরস, বা অ-চরিত্রহীন শব্দ ইত্যাদি থেকে মুক্ত।</p>', 1, 1, '2024-12-20 10:21:26', '2025-01-05 06:26:42'),
(7, 3, 1, 'In the name of your lord', 'পড় তোমার প্রভুর নামে', 'in-the-name-of-your-lord', 'upload/blog_images/1093442825.blog-hadith.png', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'upload/blog_images/127277472.blog1 - Copy.jpg', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'upload/blog_images/195433129.rose3 - Copy.jpg', 'This is title three.', 'এই শিরোনাম তিন.', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>গ্রন্থ, রেনেসাঁর সময় খুব জনপ্রিয়। Lorem Ipsum এর প্রথম লাইন, \"Lorem ipsum dolor sit amet..\", 1.10.32 ধারার একটি লাইন থেকে এসেছে।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', '<p>I am going to madrasa for learning quran.</p>', '<p>আমি কুরান শিখতে যাছি।</p>', NULL, NULL, '<p>structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>', '<p>যুক্তিসঙ্গত দেখায়। উত্পন্ন লোরেম ইপসাম তাই সবসময় পুনরাবৃত্তি, ইনজেকশন করা হাস্যরস, বা অ-চরিত্রহীন শব্দ ইত্যাদি থেকে মুক্ত।</p>', 1, 1, '2024-12-20 10:21:26', '2025-01-05 07:01:12');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint UNSIGNED NOT NULL,
  `category_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `book_pdf_file` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description1_en` text COLLATE utf8mb4_unicode_ci,
  `description1_bn` text COLLATE utf8mb4_unicode_ci,
  `topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description2_en` text COLLATE utf8mb4_unicode_ci,
  `description2_bn` text COLLATE utf8mb4_unicode_ci,
  `topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description3_en` text COLLATE utf8mb4_unicode_ci,
  `description3_bn` text COLLATE utf8mb4_unicode_ci,
  `topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description4_en` text COLLATE utf8mb4_unicode_ci,
  `description4_bn` text COLLATE utf8mb4_unicode_ci,
  `topic5_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic5_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description5_en` text COLLATE utf8mb4_unicode_ci,
  `description5_bn` text COLLATE utf8mb4_unicode_ci,
  `topic6_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic6_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description6_en` text COLLATE utf8mb4_unicode_ci,
  `description6_bn` text COLLATE utf8mb4_unicode_ci,
  `topic7_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic7_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description7_en` text COLLATE utf8mb4_unicode_ci,
  `description7_bn` text COLLATE utf8mb4_unicode_ci,
  `topic8_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic8_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description8_en` text COLLATE utf8mb4_unicode_ci,
  `description8_bn` text COLLATE utf8mb4_unicode_ci,
  `topic9_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic9_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description9_en` text COLLATE utf8mb4_unicode_ci,
  `description9_bn` text COLLATE utf8mb4_unicode_ci,
  `topic10_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic10_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description10_en` text COLLATE utf8mb4_unicode_ci,
  `description10_bn` text COLLATE utf8mb4_unicode_ci,
  `price_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_bn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_price_en` text COLLATE utf8mb4_unicode_ci,
  `original_price_bn` text COLLATE utf8mb4_unicode_ci,
  `paid_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'paid',
  `another_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `another_description_en` text COLLATE utf8mb4_unicode_ci,
  `another_description_bn` text COLLATE utf8mb4_unicode_ci,
  `footer_topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `category_id`, `user_id`, `title_en`, `title_bn`, `slug`, `image`, `video_url`, `book_pdf_file`, `description_en`, `description_bn`, `topic1_en`, `topic1_bn`, `description1_en`, `description1_bn`, `topic2_en`, `topic2_bn`, `description2_en`, `description2_bn`, `topic3_en`, `topic3_bn`, `description3_en`, `description3_bn`, `topic4_en`, `topic4_bn`, `description4_en`, `description4_bn`, `topic5_en`, `topic5_bn`, `description5_en`, `description5_bn`, `topic6_en`, `topic6_bn`, `description6_en`, `description6_bn`, `topic7_en`, `topic7_bn`, `description7_en`, `description7_bn`, `topic8_en`, `topic8_bn`, `description8_en`, `description8_bn`, `topic9_en`, `topic9_bn`, `description9_en`, `description9_bn`, `topic10_en`, `topic10_bn`, `description10_en`, `description10_bn`, `price_en`, `price_bn`, `original_price_en`, `original_price_bn`, `paid_status`, `another_image`, `another_description_en`, `another_description_bn`, `footer_topic1_en`, `footer_topic1_bn`, `footer_topic2_en`, `footer_topic2_bn`, `footer_topic3_en`, `footer_topic3_bn`, `footer_topic4_en`, `footer_topic4_bn`, `footer_topic5_en`, `footer_topic5_bn`, `footer_topic6_en`, `footer_topic6_bn`, `footer_topic7_en`, `footer_topic7_bn`, `footer_topic8_en`, `footer_topic8_bn`, `footer_topic9_en`, `footer_topic9_bn`, `footer_topic10_en`, `footer_topic10_bn`, `status`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 'Hadis is the second law source of Islam.', 'হাদিস ইসলামী শরীয়াতের দ্বিতীয় উতস', 'quran-is-the-second-law-source-of-islam', 'upload/books/2007557537.blog-hadith.png', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/r5k9h5sxjjs?si=EtW7a69__fp9CX8c\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 'upload/books/252144763.hadeeth_oshikar_karider_shongshoi_niroshon_by_dr_saqib_4th.pdf', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '500', '10', '1000', 'paid', 'upload/books/2134558659.course-img-1.jpg', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', '<p>45 BC. This book is a treatise on the theory of ethics,&nbsp;</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', '<p>45 BC. This book is a treatise on the theory of ethics,&nbsp;</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-12-22 02:38:56', '2025-01-08 00:35:47'),
(3, 3, 1, 'We are learning Quran.,', 'আমরা কুরান শিখছি্‌', 'we-are-learning-quran', 'upload/books/1002106578.blog-hadith.png', NULL, 'upload/books/1973937923.Al-kafi part 1 .pdf', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '300', '6', '600', 'paid', 'upload/books/943551147.blog-hadith.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-12-22 03:41:57', '2025-01-08 00:35:13'),
(4, 3, 1, 'We are learning Quran.।', 'আমরা কুরান শিখছি।।', 'we-are-learning-quran--', 'upload/books/2097550269.blog-hadith.png', NULL, 'upload/books/1514883128.hadeeth_oshikar_karider_shongshoi_niroshon_by_dr_saqib_4th.pdf', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'Quran is the complete code of life.', '<p>Quran is the complete code of life.</p>', '<p>Quran is the complete code of life.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '300', '6', '600', 'paid', 'upload/books/1666450557.hadith.svg', NULL, NULL, '<p>many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', '<p>many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', '<p>many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', '<p>many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-12-22 03:41:57', '2025-01-09 09:07:10'),
(5, 3, 1, 'We are learning Quran,.', 'আমরা কুরান শিখছ,।', 'we--learning-quran--', 'upload/books/1698481251.blog-hadith.png', NULL, 'upload/books/309443153.hadeeth_oshikar_karider_shongshoi_niroshon_by_dr_saqib_4th.pdf', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', '<p>45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p>', '<p>আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।আমরা কুরান শিখছি।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '300', '6', '600', 'free', 'upload/books/918154294.blog-hadith.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2024-12-22 03:41:57', '2025-01-08 00:33:56');

-- --------------------------------------------------------

--
-- Table structure for table `book_orders`
--

CREATE TABLE `book_orders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `book_id` int NOT NULL,
  `price_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_total_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_total_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `book_orders`
--

INSERT INTO `book_orders` (`id`, `user_id`, `book_id`, `price_en`, `price_bn`, `order_total_en`, `order_total_bn`, `email`, `phone_number`, `country`, `location`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES
(1, 8, 4, NULL, '300', NULL, '350.00', 'user2@gmail.com', '01719475187', 'Bangladesh', 'Natore.', 'aamarPay', 'received', '2025-01-03 08:55:43', '2025-01-03 08:55:43'),
(2, 7, 3, NULL, '300', NULL, '350.00', 'user@gmail.com', '01322425179', 'Bangladesh', 'Singra.', 'aamarPay', 'received', '2025-01-03 08:58:32', '2025-01-03 08:58:32'),
(3, 7, 4, NULL, '300', NULL, '350.00', 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', 'aamarPay', 'received', '2025-01-07 04:47:24', '2025-01-07 04:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('spatie.permission.cache', 'a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:68:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:15:\"view permission\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:17:\"create permission\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"edit permission\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:17:\"delete permission\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:9:\"view role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:11:\"create role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:9:\"edit role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:11:\"delete role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:9:\"view user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:11:\"create user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:9:\"edit user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:11:\"delete user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:13:\"view-category\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:15:\"create-category\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:13:\"edit-category\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:15:\"delete-category\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:9:\"view-blog\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:11:\"create-blog\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:9:\"edit-blog\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:11:\"delete-blog\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:16:\"edit-blog-status\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:11:\"view-course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:22;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:13:\"create-course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:23;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:11:\"edit-course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:24;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:13:\"delete-course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:25;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:18:\"edit-course-status\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:26;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:9:\"view-book\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:27;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:11:\"create-book\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:9:\"edit-book\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:29;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:11:\"delete-book\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:30;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:16:\"edit-book-status\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:31;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:12:\"book-details\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:12:\"view-package\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:33;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:14:\"create-package\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:34;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:12:\"edit-package\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:14:\"delete-package\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:13:\"view-about-us\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:37;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:15:\"create-about-us\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:38;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:13:\"edit-about-us\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:39;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:15:\"delete-about-us\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:40;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:16:\"view-testimonial\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:41;a:4:{s:1:\"a\";i:46;s:1:\"b\";s:18:\"create-testimonial\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:42;a:4:{s:1:\"a\";i:47;s:1:\"b\";s:16:\"edit-testimonial\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:43;a:4:{s:1:\"a\";i:48;s:1:\"b\";s:18:\"delete-testimonial\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:44;a:4:{s:1:\"a\";i:49;s:1:\"b\";s:20:\"view-contact-message\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:45;a:4:{s:1:\"a\";i:50;s:1:\"b\";s:11:\"view-coupon\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:46;a:4:{s:1:\"a\";i:51;s:1:\"b\";s:13:\"create-coupon\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:47;a:4:{s:1:\"a\";i:52;s:1:\"b\";s:11:\"edit-coupon\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:48;a:4:{s:1:\"a\";i:53;s:1:\"b\";s:13:\"delete-coupon\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:49;a:4:{s:1:\"a\";i:54;s:1:\"b\";s:14:\"payment-gatway\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:50;a:4:{s:1:\"a\";i:55;s:1:\"b\";s:15:\"view-book-order\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:5;}}i:51;a:4:{s:1:\"a\";i:56;s:1:\"b\";s:24:\"update-book-order-status\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:52;a:4:{s:1:\"a\";i:57;s:1:\"b\";s:17:\"read-ordered-book\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:5;}}i:53;a:4:{s:1:\"a\";i:58;s:1:\"b\";s:17:\"view-course-order\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:5;}}i:54;a:4:{s:1:\"a\";i:59;s:1:\"b\";s:18:\"view-package-order\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:5;}}i:55;a:4:{s:1:\"a\";i:60;s:1:\"b\";s:11:\"view-notice\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:56;a:4:{s:1:\"a\";i:61;s:1:\"b\";s:13:\"delete-notice\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:57;a:4:{s:1:\"a\";i:62;s:1:\"b\";s:13:\"create-notice\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:58;a:4:{s:1:\"a\";i:63;s:1:\"b\";s:10:\"class-link\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:5;}}i:59;a:4:{s:1:\"a\";i:64;s:1:\"b\";s:16:\"why-studyus-view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:60;a:4:{s:1:\"a\";i:65;s:1:\"b\";s:18:\"why-studyus-create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:61;a:4:{s:1:\"a\";i:66;s:1:\"b\";s:16:\"why-studyus-edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:62;a:4:{s:1:\"a\";i:67;s:1:\"b\";s:18:\"why-studyus-delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:63;a:4:{s:1:\"a\";i:68;s:1:\"b\";s:12:\"join-us-view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:64;a:4:{s:1:\"a\";i:69;s:1:\"b\";s:27:\"english-site-enrolment-view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:65;a:4:{s:1:\"a\";i:70;s:1:\"b\";s:7:\"setting\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:4;i:2;i:5;}}i:66;a:4:{s:1:\"a\";i:71;s:1:\"b\";s:15:\"setting.profile\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:4;i:2;i:5;}}i:67;a:4:{s:1:\"a\";i:72;s:1:\"b\";s:16:\"setting.password\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:4;i:2;i:5;}}}s:5:\"roles\";a:5:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:11:\"super admin\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:7:\"manager\";s:1:\"c\";s:3:\"web\";}i:3;a:3:{s:1:\"a\";i:5;s:1:\"b\";s:4:\"user\";s:1:\"c\";s:3:\"web\";}i:4;a:3:{s:1:\"a\";i:4;s:1:\"b\";s:7:\"teacher\";s:1:\"c\";s:3:\"web\";}}}', 1736511270);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_en`, `name_bn`, `slug`, `created_at`, `updated_at`) VALUES
(3, 'Al Quran', 'আল কুরআন', 'al-quran', '2024-12-20 00:44:45', '2024-12-20 00:44:45'),
(4, 'Al Hadis', 'আল হাদিস', 'al-hadis', '2024-12-20 00:44:54', '2024-12-20 00:44:54'),
(5, 'Dawah', 'দাওয়াহ', 'dawah', '2024-12-20 00:45:21', '2024-12-20 00:45:21'),
(6, 'Hefjo', 'হেফজো', 'hefjo', '2024-12-20 00:45:49', '2024-12-20 00:45:49');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_status` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `phone`, `country`, `subject`, `message`, `view_status`, `created_at`, `updated_at`) VALUES
(1, 'karim', 'karim@gmail.com', '01719475187', NULL, 'Dawah Course', 'I am a followers of your course. When your dawah course will be started?', 1, '2024-12-20 10:21:26', '2024-12-24 07:54:35'),
(2, 'amir hamja', 'amir@gmail.com', '0122336688', NULL, 'About Singra', 'what is the present news of singra thana of natore district???', 1, '2025-01-06 08:52:05', '2025-01-06 08:52:57'),
(3, 'kajol', 'kajol@gmail.com', '098888888', NULL, 'Asia cup', 'Which team do you support in asia cup?', 0, '2025-01-06 08:54:11', '2025-01-06 08:54:11'),
(4, 'dgdh', 'gfjgjg@gmail.com', '01719475187', NULL, 'sgdg', 'fghfhj', 0, '2025-01-06 08:57:49', '2025-01-06 08:57:49'),
(5, 'harun', 'harun@gmail.com', '55766846757', NULL, 'dhdh', 'gdhdhfhj', 0, '2025-01-06 09:00:33', '2025-01-06 09:00:33'),
(6, 'fddh', 'fffff@gmail.com', '01719475187', NULL, 'fhfh', 'ddhh', 1, '2025-01-06 09:01:24', '2025-01-07 05:33:04'),
(7, 'Md Sohel Rana', 'rana@gmail.com', '01322454543', 'Bangladesh', 'Rajshahi city', 'What is the famous thing of rajshahi city?', 0, '2025-01-07 23:56:13', '2025-01-07 23:56:13'),
(8, 'Rubel', 'rubel@gmail.com', '01890121245', 'Pakistan', 'Profession', 'Can i join your community as a teacher?', 0, '2025-01-07 23:57:45', '2025-01-07 23:57:45');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `validity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `discount_amount_en`, `discount_amount_bn`, `validity`, `created_at`, `updated_at`) VALUES
(1, 'mycoupon1230', '6', '600', '08-08-2025', '2024-12-25 03:08:29', '2024-12-29 05:34:19');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint UNSIGNED NOT NULL,
  `course_category_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `teacher_id` bigint UNSIGNED NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic5_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic5_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic6_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic6_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic7_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic7_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic8_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic8_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic9_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic9_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic10_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic10_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic11_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic11_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic12_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic12_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic13_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic13_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic14_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic14_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic15_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic15_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image2` text COLLATE utf8mb4_unicode_ci,
  `content2_en` text COLLATE utf8mb4_unicode_ci,
  `content2_bn` text COLLATE utf8mb4_unicode_ci,
  `footer_topic1_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic1_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic2_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic3_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic4_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic5_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic6_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic7_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic8_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic9_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_topic10_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature1_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature1_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature2_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature2_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature3_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature3_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature4_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature4_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature5_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature5_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature6_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature6_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature7_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature7_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature8_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature8_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature9_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature9_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature10_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature10_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price_en` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price_bn` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `original_price_en` text COLLATE utf8mb4_unicode_ci,
  `original_price_bn` text COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_category_id`, `user_id`, `teacher_id`, `title_en`, `title_bn`, `slug`, `image`, `video_url`, `content_en`, `content_bn`, `topic1_en`, `topic1_bn`, `topic2_en`, `topic2_bn`, `topic3_en`, `topic3_bn`, `topic4_en`, `topic4_bn`, `topic5_en`, `topic5_bn`, `topic6_en`, `topic6_bn`, `topic7_en`, `topic7_bn`, `topic8_en`, `topic8_bn`, `topic9_en`, `topic9_bn`, `topic10_en`, `topic10_bn`, `topic11_en`, `topic11_bn`, `topic12_en`, `topic12_bn`, `topic13_en`, `topic13_bn`, `topic14_en`, `topic14_bn`, `topic15_en`, `topic15_bn`, `image2`, `content2_en`, `content2_bn`, `footer_topic1_en`, `footer_topic1_bn`, `footer_topic2_en`, `footer_topic2_bn`, `footer_topic3_en`, `footer_topic3_bn`, `footer_topic4_en`, `footer_topic4_bn`, `footer_topic5_en`, `footer_topic5_bn`, `footer_topic6_en`, `footer_topic6_bn`, `footer_topic7_en`, `footer_topic7_bn`, `footer_topic8_en`, `footer_topic8_bn`, `footer_topic9_en`, `footer_topic9_bn`, `footer_topic10_en`, `footer_topic10_bn`, `feature1_en`, `feature1_bn`, `feature2_en`, `feature2_bn`, `feature3_en`, `feature3_bn`, `feature4_en`, `feature4_bn`, `feature5_en`, `feature5_bn`, `feature6_en`, `feature6_bn`, `feature7_en`, `feature7_bn`, `feature8_en`, `feature8_bn`, `feature9_en`, `feature9_bn`, `feature10_en`, `feature10_bn`, `price_en`, `price_bn`, `original_price_en`, `original_price_bn`, `status`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 4, 'Hadis is the complete code of life.', 'হাদিস হল পূর্ণাঙ্গ জীবন বিধান।', 'hadis-is-the-complete-code-of-life', 'upload/course_images/115157094.blog-hadith.png', NULL, '<p>Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'upload/course_images/1921502671.course-img-1.jpg', '<p>Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.Quran is the complete code of life.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3', '2000', '6', '4000', 1, '2024-12-21 10:08:03', '2025-01-09 07:25:47'),
(2, 3, 1, 5, 'Quran is the forkan.', 'কুরান হলো ফুরকান', 'quran-is-the-forqan', 'upload/course_images/1527171076.blog-hadith.png', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '<p>I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।</p><p>&nbsp;</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'upload/course_images/1142695311.course-img-1.jpg', '<p>&nbsp;am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '2500', '10', '5000', 1, '2024-12-21 10:12:36', '2025-01-08 00:15:47'),
(4, 3, 1, 5, 'quran is the law of our life', 'কুরআন আমাদের জীবনের নিয়ম', 'we-is-the-law-of-life', 'upload/course_images/1178499680.blog-hadith.png', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '<p>I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।</p><p>&nbsp;</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'upload/course_images/371009594.course-img-1.jpg', '<p>&nbsp;am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '2500', '10', '5000', 1, '2024-12-21 10:12:36', '2025-01-08 00:14:02'),
(5, 3, 1, 5, 'We are learning Quran.,,', 'আমরা কুরান শিখছি।,,', 'we-learning-quran-', 'upload/course_images/992379309.blog-hadith.png', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/LuflDVJ4abU?si=atYhZoqenXJgxzBe\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '<p>I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।আমি স্কুলে যাইতেছি।</p><p>&nbsp;</p>', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', 'Quran is the complete code of life.', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান।', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'upload/course_images/1968249042.course-img-1.jpg', '<p>&nbsp;am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.I am going to school.</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p><strong>Quran</strong> is the complete code of life</p>', '<p><strong>কুরআন:</strong> হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', '<p>Quran is the complete code of life</p>', '<p>কুরআন হল পূর্ণাঙ্গ জীবন বিধান।কুরআন হল পূর্ণাঙ্গ জীবন বিধান।</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', 'Quran is the complete code of life', 'কুরআন হল পূর্ণাঙ্গ জীবন বিধান', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '2500', '10', '5000', 1, '2024-12-21 10:12:36', '2025-01-08 00:15:14');

-- --------------------------------------------------------

--
-- Table structure for table `course_orders`
--

CREATE TABLE `course_orders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `price_en` decimal(10,2) DEFAULT NULL,
  `price_bn` decimal(10,2) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_orders`
--

INSERT INTO `course_orders` (`id`, `user_id`, `course_id`, `price_en`, `price_bn`, `email`, `phone_number`, `country`, `location`, `total_en`, `total_bn`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES
(1, 7, 4, NULL, 2500.00, 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', NULL, '1900.00', 'aamarPay', 'received', '2025-01-02 04:42:31', '2025-01-02 04:42:31'),
(2, 7, 5, NULL, 2500.00, 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', NULL, '2500.00', 'aamarPay', 'received', '2025-01-02 04:44:29', '2025-01-02 04:44:29'),
(3, 7, 2, NULL, 2500.00, 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', NULL, '2500.00', 'aamarPay', 'received', '2025-01-02 04:49:15', '2025-01-02 04:49:15'),
(4, 8, 1, NULL, 2000.00, 'user2@gmail.com', '01322425179', 'Bangladesh', 'Singra', NULL, '2000.00', 'aamarPay', 'received', '2025-01-02 05:03:22', '2025-01-02 05:03:22'),
(5, 7, 4, NULL, 2500.00, 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', NULL, '1900.00', 'aamarPay', 'received', '2025-01-03 10:22:27', '2025-01-03 10:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `teacher_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `days` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `name`, `email`, `phone`, `country`, `course_id`, `teacher_type`, `days`, `created_at`, `updated_at`) VALUES
(1, 'Kamal', 'kamal@mail.xyz', '11111111', 'Kajakistan', 2, 'female', 'Friday', '2025-01-08 11:31:03', '2025-01-08 11:31:38'),
(2, 'Jandu', 'jandu@gmail.com', '77777', 'Katar', 5, 'male', 'Thursday', '2025-01-08 11:32:32', '2025-01-08 11:33:20'),
(3, 'Khumini', 'khumini@gmail.com', '01719475187', 'Iran', 1, 'other', 'Wednesday', '2025-01-08 11:34:16', '2025-01-08 11:34:48'),
(4, 'goni', 'goni@gmail.com', '6666', 'Kuet', 4, 'female', 'Saturday', '2025-01-08 11:51:00', '2025-01-08 11:51:19'),
(5, 'Bushra khatun', 'bsra@gmail.com', '0998877', 'Srilanka', 1, 'female', 'Friday', '2025-01-09 03:30:45', '2025-01-09 03:31:17'),
(6, 'Roni', 'roni@gmail.com', '465758', 'Sukash', 4, 'male', 'Thursday', '2025-01-09 03:34:19', '2025-01-09 03:34:52'),
(7, 'Julkarnaine', 'julkar@gmail.com', '4575888', 'Misor', 2, 'other', 'Saturday', '2025-01-09 03:38:21', '2025-01-09 03:39:10'),
(8, 'dgddh', 'dfsf@gmail.com', '01719475187', 'Bangladesh', 2, 'female', 'Sunday', '2025-01-09 08:37:21', '2025-01-09 08:37:27'),
(9, 'demo', 'demo@gmail.com', '35466', 'pakistan', 2, 'female', 'Wednesday', '2025-01-09 08:45:48', '2025-01-09 08:45:55'),
(10, 'bcnn', 'mrkkarim1991@gmail.com', '01719475187', 'Bangladesh', 2, 'female', 'Wednesday', '2025-01-09 08:46:25', '2025-01-09 08:46:31'),
(11, 'Rezaul Karim', 'mrkkarim1991@gmail.com', '01719475187', 'Bangladesh', NULL, NULL, NULL, '2025-01-09 09:42:15', '2025-01-09 09:42:15'),
(12, 'Selina', 'selina@gmail.com', '01719475187', 'Bangladesh', 2, 'female', 'Sunday', '2025-01-09 10:04:03', '2025-01-09 10:04:38'),
(13, 'Imran', 'imran@gmail.com', '1223455556', 'Bangladesh', 2, 'female', 'Sunday', '2025-01-09 10:15:20', '2025-01-09 10:16:23'),
(14, 'Rezaul Karim', 'mrkkarim1991@gmail.com', '01719475187', 'Bangladesh', 2, 'female', 'Wednesday', '2025-01-09 10:19:38', '2025-01-09 10:19:57');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_10_25_135723_create_permission_tables', 1),
(7, '2024_11_03_103544_create_course_categories_table', 2),
(13, '2024_12_16_052631_create_categories_table', 6),
(14, '2024_10_29_151138_create_blogs_table', 7),
(17, '2024_11_03_111122_create_courses_table', 10),
(18, '2024_12_16_073018_create_books_table', 11),
(19, '2024_12_23_095231_create_packages_table', 12),
(20, '2024_12_23_100216_create_about_us_table', 13),
(21, '2024_12_23_101337_create_testimonials_table', 14),
(22, '2024_12_23_102007_create_contact_us_table', 15),
(23, '2024_12_25_082534_create_coupons_table', 16),
(24, '2024_12_29_115834_create_course_orders_table', 17),
(26, '2024_12_29_120916_create_user_infos_table', 18),
(27, '2025_01_01_104652_create_payment_gateways_table', 19),
(28, '2025_01_02_110859_create_package_orders_table', 20),
(29, '2025_01_03_115250_create_book_orders_table', 21),
(31, '2025_01_05_053712_create_notices_table', 22),
(32, '2025_01_05_080306_create_whystudy_us_table', 23),
(33, '2025_01_08_011814_create_newsletters_table', 24),
(35, '2025_01_08_084719_create_enrollments_table', 25);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 4),
(4, 'App\\Models\\User', 5),
(4, 'App\\Models\\User', 6),
(5, 'App\\Models\\User', 7),
(5, 'App\\Models\\User', 8),
(5, 'App\\Models\\User', 9),
(5, 'App\\Models\\User', 10);

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE `newsletters` (
  `id` bigint UNSIGNED NOT NULL,
  `email_or_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newsletters`
--

INSERT INTO `newsletters` (`id`, `email_or_phone`, `created_at`, `updated_at`) VALUES
(1, '01719475187', '2025-01-07 19:32:29', '2025-01-07 19:32:29'),
(2, 'mrkkarim1991@gmail.com', '2025-01-07 19:33:08', '2025-01-07 19:33:08'),
(3, 'demo@gmail.com', '2025-01-07 19:34:45', '2025-01-07 19:34:45');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` bigint UNSIGNED NOT NULL,
  `course_id` int NOT NULL,
  `class_link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `course_id`, `class_link`, `content`, `date`, `created_at`, `updated_at`) VALUES
(5, 5, 'https://meet.google.com/landing', 'Today class will start at 9:pm at bangladeshi time.', '05-01-2025', '2025-01-05 01:57:32', '2025-01-05 01:57:32'),
(6, 5, 'https://meet.google.com/landing', NULL, '05-01-2025', '2025-01-05 02:00:47', '2025-01-05 02:00:47'),
(7, 2, 'https://meet.google.com/bdi-eqid-cuv', 'today will start at time ksglkdsgldkh', '07-01-2025', '2025-01-07 05:25:26', '2025-01-07 05:25:26');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint UNSIGNED NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature1_en` text COLLATE utf8mb4_unicode_ci,
  `feature1_bn` text COLLATE utf8mb4_unicode_ci,
  `feature2_en` text COLLATE utf8mb4_unicode_ci,
  `feature2_bn` text COLLATE utf8mb4_unicode_ci,
  `feature3_en` text COLLATE utf8mb4_unicode_ci,
  `feature3_bn` text COLLATE utf8mb4_unicode_ci,
  `feature4_en` text COLLATE utf8mb4_unicode_ci,
  `feature4_bn` text COLLATE utf8mb4_unicode_ci,
  `feature5_en` text COLLATE utf8mb4_unicode_ci,
  `feature5_bn` text COLLATE utf8mb4_unicode_ci,
  `feature6_en` text COLLATE utf8mb4_unicode_ci,
  `feature6_bn` text COLLATE utf8mb4_unicode_ci,
  `feature7_en` text COLLATE utf8mb4_unicode_ci,
  `feature7_bn` text COLLATE utf8mb4_unicode_ci,
  `feature8_en` text COLLATE utf8mb4_unicode_ci,
  `feature8_bn` text COLLATE utf8mb4_unicode_ci,
  `feature9_en` text COLLATE utf8mb4_unicode_ci,
  `feature9_bn` text COLLATE utf8mb4_unicode_ci,
  `feature10_en` text COLLATE utf8mb4_unicode_ci,
  `feature10_bn` text COLLATE utf8mb4_unicode_ci,
  `feature1_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature2_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature3_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature4_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature5_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature6_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature7_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature8_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature9_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `feature10_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name_en`, `name_bn`, `description_en`, `description_bn`, `price_en`, `price_bn`, `feature1_en`, `feature1_bn`, `feature2_en`, `feature2_bn`, `feature3_en`, `feature3_bn`, `feature4_en`, `feature4_bn`, `feature5_en`, `feature5_bn`, `feature6_en`, `feature6_bn`, `feature7_en`, `feature7_bn`, `feature8_en`, `feature8_bn`, `feature9_en`, `feature9_bn`, `feature10_en`, `feature10_bn`, `feature1_status`, `feature2_status`, `feature3_status`, `feature4_status`, `feature5_status`, `feature6_status`, `feature7_status`, `feature8_status`, `feature9_status`, `feature10_status`, `created_at`, `updated_at`) VALUES
(1, 'Basic', 'বেসিক', 'Get an Essential features included in our basic plan', 'আমাদের মৌলিক পরিকল্পনায় অন্তর্ভুক্ত একটি অপরিহার্য বৈশিষ্ট্য পান', '8', '800', '2 days per week class', 'সপ্তাহে ২ দিন ক্লাস', 'Class duration 1 hour', 'ক্লাসের সময়কাল 1 ঘন্টা', 'Free E-Books', 'ফ্রি ই-বুক', '24/7 Support', '২৪/৭ সাপোর্ট', 'sss', 'এসেসেস', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', 'yes', 'yes', 'yes', 'no', NULL, NULL, NULL, NULL, NULL, '2024-12-23 05:36:38', '2024-12-27 09:32:05'),
(3, 'Standard', 'মানসম্মত', 'Get an Essential features included in our basic plan', 'আমাদের মৌলিক পরিকল্পনায় অন্তর্ভুক্ত একটি অপরিহার্য বৈশিষ্ট্য পান', '15', '1500', '2 days per week class', 'সপ্তাহে ২ দিন ক্লাস', 'Class duration 1 hour', 'ক্লাসের সময়কাল 1 ঘন্টা', 'Free E-Books', 'বিনামূল্যের ই-বুক', '24/7 Support', '২৪/৭ সাপোর্ট', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ddd', 'ডিডিডি', 'yes', 'yes', 'no', 'no', NULL, NULL, NULL, NULL, NULL, 'yes', '2024-12-23 05:51:48', '2024-12-27 09:33:29');

-- --------------------------------------------------------

--
-- Table structure for table `package_orders`
--

CREATE TABLE `package_orders` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int NOT NULL,
  `package_id` int NOT NULL,
  `price_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_total_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_total_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `package_orders`
--

INSERT INTO `package_orders` (`id`, `user_id`, `package_id`, `price_en`, `price_bn`, `order_total_en`, `order_total_bn`, `email`, `phone_number`, `country`, `location`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES
(1, 8, 1, NULL, '800', NULL, '800.00', 'user2@gmail.com', '01719475187', 'Bangladesh', 'Raninogor', 'aamarPay', 'received', '2025-01-02 06:29:46', '2025-01-02 06:29:46'),
(2, 7, 1, NULL, '800', NULL, '200.00', 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', 'aamarPay', 'received', '2025-01-02 06:31:44', '2025-01-02 06:31:44');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` bigint UNSIGNED NOT NULL,
  `gateway_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `gateway_name`, `store_id`, `signature_key`, `status`, `created_at`, `updated_at`) VALUES
(1, 'aamarPay', 'aamarpaytest', 'dbb74894e82415a2f7ff0ec3a97e4183', '0', NULL, '2025-01-01 05:00:57');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'view permission', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(2, 'create permission', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(3, 'edit permission', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(4, 'delete permission', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(5, 'view role', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(6, 'create role', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(7, 'edit role', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(8, 'delete role', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(9, 'view user', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(10, 'create user', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(11, 'edit user', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(12, 'delete user', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(13, 'view-category', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(14, 'create-category', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(15, 'edit-category', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(16, 'delete-category', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(17, 'view-blog', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(18, 'create-blog', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(19, 'edit-blog', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(20, 'delete-blog', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(21, 'edit-blog-status', 'web', '2024-11-03 04:20:10', '2024-11-03 04:20:10'),
(26, 'view-course', 'web', '2024-11-03 05:09:12', '2024-11-03 05:09:12'),
(27, 'create-course', 'web', '2024-11-03 05:09:25', '2024-11-03 05:09:25'),
(28, 'edit-course', 'web', '2024-11-03 05:09:34', '2024-11-03 05:09:34'),
(29, 'delete-course', 'web', '2024-11-03 05:09:44', '2024-11-03 05:09:44'),
(30, 'edit-course-status', 'web', '2024-11-03 06:38:07', '2024-11-03 06:38:07'),
(31, 'view-book', 'web', '2024-12-21 23:51:31', '2024-12-21 23:51:31'),
(32, 'create-book', 'web', '2024-12-21 23:51:50', '2024-12-21 23:51:50'),
(33, 'edit-book', 'web', '2024-12-21 23:51:59', '2024-12-21 23:51:59'),
(34, 'delete-book', 'web', '2024-12-21 23:52:10', '2024-12-21 23:52:10'),
(35, 'edit-book-status', 'web', '2024-12-21 23:55:04', '2024-12-21 23:55:04'),
(36, 'book-details', 'web', '2024-12-22 03:29:35', '2024-12-22 03:29:35'),
(37, 'view-package', 'web', '2024-12-23 04:30:30', '2024-12-23 04:30:30'),
(38, 'create-package', 'web', '2024-12-23 04:30:53', '2024-12-23 04:30:53'),
(39, 'edit-package', 'web', '2024-12-23 04:31:05', '2024-12-23 04:31:05'),
(40, 'delete-package', 'web', '2024-12-23 04:31:20', '2024-12-23 04:31:20'),
(41, 'view-about-us', 'web', '2024-12-23 05:58:13', '2024-12-23 05:58:13'),
(42, 'create-about-us', 'web', '2024-12-23 05:58:43', '2024-12-23 05:58:43'),
(43, 'edit-about-us', 'web', '2024-12-23 05:58:55', '2024-12-23 05:58:55'),
(44, 'delete-about-us', 'web', '2024-12-23 06:00:31', '2024-12-23 06:00:31'),
(45, 'view-testimonial', 'web', '2024-12-24 06:26:08', '2024-12-24 06:26:08'),
(46, 'create-testimonial', 'web', '2024-12-24 06:26:24', '2024-12-24 06:26:24'),
(47, 'edit-testimonial', 'web', '2024-12-24 06:26:40', '2024-12-24 06:26:40'),
(48, 'delete-testimonial', 'web', '2024-12-24 06:26:55', '2024-12-24 06:26:55'),
(49, 'view-contact-message', 'web', '2024-12-24 07:52:16', '2024-12-24 07:52:16'),
(50, 'view-coupon', 'web', '2024-12-25 02:34:22', '2024-12-25 02:34:22'),
(51, 'create-coupon', 'web', '2024-12-25 02:34:36', '2024-12-25 02:34:36'),
(52, 'edit-coupon', 'web', '2024-12-25 02:34:51', '2024-12-25 02:34:51'),
(53, 'delete-coupon', 'web', '2024-12-25 02:35:11', '2024-12-25 02:35:11'),
(54, 'payment-gatway', 'web', '2025-01-01 04:19:59', '2025-01-01 04:19:59'),
(55, 'view-book-order', 'web', '2025-01-03 06:37:13', '2025-01-03 06:37:13'),
(56, 'update-book-order-status', 'web', '2025-01-03 07:22:34', '2025-01-03 07:22:34'),
(57, 'read-ordered-book', 'web', '2025-01-03 07:42:26', '2025-01-03 07:42:26'),
(58, 'view-course-order', 'web', '2025-01-04 21:37:33', '2025-01-04 21:37:33'),
(59, 'view-package-order', 'web', '2025-01-04 23:22:49', '2025-01-04 23:22:49'),
(60, 'view-notice', 'web', '2025-01-04 23:41:07', '2025-01-04 23:41:07'),
(61, 'delete-notice', 'web', '2025-01-04 23:41:19', '2025-01-04 23:41:19'),
(62, 'create-notice', 'web', '2025-01-04 23:44:55', '2025-01-04 23:44:55'),
(63, 'class-link', 'web', '2025-01-05 00:44:20', '2025-01-05 00:44:20'),
(64, 'why-studyus-view', 'web', '2025-01-05 02:06:33', '2025-01-05 02:06:33'),
(65, 'why-studyus-create', 'web', '2025-01-05 02:06:43', '2025-01-05 02:06:43'),
(66, 'why-studyus-edit', 'web', '2025-01-05 02:06:54', '2025-01-05 02:06:54'),
(67, 'why-studyus-delete', 'web', '2025-01-05 02:07:02', '2025-01-05 02:07:02'),
(68, 'join-us-view', 'web', '2025-01-07 19:35:44', '2025-01-07 19:35:44'),
(69, 'english-site-enrolment-view', 'web', '2025-01-09 05:03:33', '2025-01-09 05:03:33'),
(70, 'setting', 'web', '2025-01-09 05:26:46', '2025-01-09 05:26:46'),
(71, 'setting.profile', 'web', '2025-01-09 05:26:56', '2025-01-09 05:26:56'),
(72, 'setting.password', 'web', '2025-01-09 05:27:07', '2025-01-09 05:27:07');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2024-11-03 04:20:10', '2024-11-03 04:32:54'),
(2, 'super admin', 'web', '2024-11-03 04:22:08', '2024-11-03 04:22:08'),
(3, 'manager', 'web', '2024-12-10 09:28:34', '2024-12-10 09:28:34'),
(4, 'teacher', 'web', '2024-12-21 00:36:28', '2024-12-21 08:40:53'),
(5, 'user', 'web', '2024-12-21 11:53:26', '2024-12-21 11:54:24');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(17, 2),
(18, 2),
(19, 2),
(20, 2),
(21, 2),
(26, 2),
(27, 2),
(28, 2),
(29, 2),
(30, 2),
(17, 3),
(18, 3),
(19, 3),
(20, 3),
(26, 3),
(27, 3),
(28, 3),
(29, 3),
(70, 4),
(71, 4),
(72, 4),
(55, 5),
(57, 5),
(58, 5),
(59, 5),
(63, 5),
(70, 5),
(71, 5),
(72, 5);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('at1SjBBBtjX8Lw5wVkBtRZY312bJLKminVd2clIM', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYUhNMkVXeHRGQW5GejFRMzMyUjdJUDJDWW12SlFtZGMyYVJzTFJuNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NDoibGFuZyI7czo3OiJlbmdsaXNoIjt9', 1736442065),
('CsLm3pTF3NDugKsetc3x9mKrlFOjTvUQ1MQZXfvL', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOEFJVlhhOWFFRDN5RG1CQmJrME13dlFUZ21YYTVKWjdMdWNIU2thZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736430571),
('I5a4213Jbu2fVxD521XiPmc7hyZwC90Hl6iyGsYT', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia2x6SjFOUXdlRTBMUm41T01QRGVQVkV4U3V1RmN5UUxrck9ac0pnMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1736440444),
('OV1p7RbPGoUQ8gFy9DA0YshjgNdwLOxuOnVlFPKg', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMlBzcEJmcWhoTVIyNVhkVFFjcjA2VkQ3SGRPMFdScGpoNDRWa0NGbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC91c2VyL2Rhc2hib2FyZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjU7fQ==', 1736430588),
('VLKrfqB81l0PqANoUCzFc1GW1F2iHG3yBWozns0E', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoidDQ1eDRvNkx5SWhiS3ZqbWJzNE5EdUdRNjRjNmhqV3VsWGsxT1VWYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9ib29rL2VkaXQvNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NDoibGFuZyI7czo3OiJlbmdsaXNoIjtzOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1736435240);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` bigint UNSIGNED NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profession_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profession_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_en` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `title_en`, `title_bn`, `logo`, `description_en`, `description_bn`, `image`, `name_en`, `name_bn`, `profession_en`, `profession_bn`, `country_en`, `country_bn`, `created_at`, `updated_at`) VALUES
(1, 'I am going to School.', 'আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/578429980.logo2.png', 'I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.', 'আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/1013071967.jeet.jpg', 'Abdullah al mamun', 'আবদুল্লাহ আল মামুন', 'Teacher', 'শিক্ষক', 'Pakistan', 'পাকিস্তান', '2024-12-24 07:12:18', '2025-01-09 03:48:14'),
(2, 'I am going to School.', 'আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/334202968.logo2.png', 'I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.', 'আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/505153630.g1.jpg', 'Rakibul Hasan', 'রাকিবুল হাসান', 'Student', 'ছাত্র', 'Bangladesh', 'বাংলাদেশ', '2024-12-24 07:12:18', '2025-01-09 03:48:46'),
(3, 'I am going to School.', 'আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/745782954.rose3.jpg', 'I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.I am going to School.', 'আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।আমি স্কুলে যাচ্ছি।', 'upload/testimonial_images/1152663866.sarukh (2).jpg', 'Sohanur Rahman', 'সোহানুর রহমান', 'Businessman', 'ব্যবসায়ী', 'Arab', 'আরব', '2024-12-24 07:12:18', '2025-01-09 03:49:12'),
(5, 'Tushar', 'তুষার', 'upload/testimonial_images/2082924256.blog1.jpg', '\"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"\r\n\"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...\"', '\"এমন কেউ নেই যে ব্যথাকে ভালোবাসে কারণ এটি ব্যথা, এটি অনুসরণ করে, লাভ করতে চায় ...\"\r\n\"এমন কেউ নেই যে নিজেই ব্যথাকে ভালবাসে, যে এটির সন্ধান করে এবং এটি পেতে চায়, কেবল কারণ এটি ব্যথা ...\"', 'upload/testimonial_images/1653736782.sarukh (2).jpg', 'Tushar', 'তুষার', 'Teachr', 'শিক্ষক', 'Egypt', 'মিশর', '2025-01-09 03:53:46', '2025-01-09 03:53:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci,
  `teacher_linkedin` text COLLATE utf8mb4_unicode_ci,
  `teacher_description` text COLLATE utf8mb4_unicode_ci,
  `teacher_description_bn` text COLLATE utf8mb4_unicode_ci,
  `teacher_degree_inst` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_degree_inst_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_degree` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_degree_bn` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_degree_subject` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_degree_subject_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `name_bn`, `email`, `email_verified_at`, `password`, `image`, `teacher_linkedin`, `teacher_description`, `teacher_description_bn`, `teacher_degree_inst`, `teacher_degree_inst_bn`, `teacher_degree`, `teacher_degree_bn`, `t_degree_subject`, `t_degree_subject_bn`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'এডমিন', 'admin@gmail.com', NULL, '$2y$12$CDa8hFBFbwInSqmqLvXvqeS4T/lQ6K5IQLH2HYEL68JHjT8FrVHLK', 'upload/user_images/832991546.g1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-03 04:20:10', '2025-01-09 06:39:28'),
(2, 'Super Admin', NULL, 'superadmin@gmail.com', NULL, '$2y$12$EfhMlOu9HIe2/hfsO46eO.CFdlUgv7OSCTPRduqU.MjMel1pLW/l6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-03 04:23:09', '2024-11-03 04:23:09'),
(3, 'Belal Uddajaman', NULL, 'belal@gmail.com', NULL, '$2y$12$n70t.ks3eWFdRlk3jbskpe5BWgBfIltBeN98SE6rwjVYM1cOsosx2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-12-10 09:30:06', '2024-12-10 09:30:06'),
(4, 'masum', 'মাসুম', 'masum@gmail.com', NULL, '$2y$12$rADtqknRbdN.9Rb21M7ft.m6CYmC6TR1mBrw5XHzIQ2RwyrFYkWQO', 'upload/user_images/216276589.maulana1.jpeg', 'https://www.linkedin.com', 'masum is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.Kafil is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.', 'মাসুম একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন। কফিল একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন।', 'Madina University', 'মদিনা বিশ্ববিদ্যালয়', 'Kamel', 'কামিল', 'Dawah', 'দাওয়াহ', NULL, '2024-12-21 00:36:59', '2024-12-27 11:57:22'),
(5, 'Jafor', 'জাফর', 'jafor@gmail.com', NULL, '$2y$12$nKlOROKdtZu5Xf6pJdPL7OwSgNBUGAMkWWmKKtUUVqtpWIBglMTkG', 'upload/user_images/1667859100.maulana2.jpeg', 'https://www.linkedin.com', 'Jafor is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.Kafil is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.', 'জাফর একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন। কফিল একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন।', 'Rajshahi University.', 'রাজশাহী বিশ্ববিদ্যালয়।', 'BA Hons', 'বিএ অনার্স', 'Arabic', 'আরবি সাহিত্য', NULL, '2024-12-21 08:41:34', '2025-01-09 06:41:53'),
(6, 'Kafil Uddin', 'কফিল উদ্দিন আহম্মেদ', 'kafil@gmail.com', NULL, '$2y$12$.ObJrhLXktwQS8kJOvOLh.nIIc3QQKK8u1Bh94AeErBibn1/TvXn6', 'upload/user_images/1657741177.maulana1.jpeg', 'https://www.linkedin.com', 'Kafil is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.Kafil is an expert teacher. He is an MA. He has completed his BA hons degree from a public university.', 'কফিল একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন। কফিল একজন বিশেষজ্ঞ শিক্ষক। তিনি এম.এ. তিনি একটি পাবলিক বিশ্ববিদ্যালয় থেকে বিএ অনার্স সম্পন্ন করেছেন।', 'Al azhar university.', 'আল আজহার ইউনিভার্সিটি।', 'BA Hons', 'বিএ অনার্স', 'Al hadis', 'আল হাদিস', NULL, '2024-12-25 01:11:38', '2024-12-27 11:57:42'),
(7, 'User', 'ইউজার', 'user@gmail.com', NULL, '$2y$12$JIIfw8dc/fIuG1otFop/XeMWGLvAjXQwEexJa6IIyQipomxdwsxCW', 'upload/user_images/1822332139.salman (3).jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-12-27 01:16:08', '2024-12-27 01:16:08'),
(8, 'User2', 'ইউজার২', 'user2@gmail.com', NULL, '$2y$12$iBhzNhDDfzXQvhMdy4rtgeIb1Px97RHPPGl4lvDK.xEPDlYNQ7VLC', 'upload/user_images/1252552341.g5 - Copy.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-02 05:00:04', '2025-01-02 05:00:04'),
(9, 'User3', 'ইউজার৩', 'user3@gmail.com', NULL, '$2y$12$AU/NcQT1RiUK/jCvql.ssetrjaTFMP8nwBCxvFGI8UbF/Q.330eDi', 'upload/user_images/798336913.g4.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-02 05:01:10', '2025-01-02 05:01:10'),
(10, 'Moon Islam', NULL, 'moon@gmail.com', NULL, '$2y$12$k6PT.efPyMxT5yBgYRL3suqmv3OkpztuUpglD3FFxU60agxzmOMN2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-01-06 10:21:54', '2025-01-06 10:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_infos`
--

CREATE TABLE `user_infos` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_infos`
--

INSERT INTO `user_infos` (`id`, `user_id`, `email`, `phone_number`, `country`, `location`, `created_at`, `updated_at`) VALUES
(1, 7, 'user@gmail.com', '01719475188', 'Bangladesh', 'Natore.', '2024-12-29 07:22:06', '2024-12-29 07:24:18');

-- --------------------------------------------------------

--
-- Table structure for table `whystudy_us`
--

CREATE TABLE `whystudy_us` (
  `id` bigint UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_en` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `whystudy_us`
--

INSERT INTO `whystudy_us` (`id`, `image`, `title_en`, `title_bn`, `description_en`, `description_bn`, `created_at`, `updated_at`) VALUES
(1, 'upload/why_studyus_images/847637689.study1.svg', '24/7 services', '২৪/৭ সাপোর্ট', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।uu', '2025-01-05 03:52:09', '2025-01-05 05:42:01'),
(2, 'upload/why_studyus_images/1225455037.study2.svg', 'Best Tutor', 'বেস্ট টিউটর', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।', '2025-01-05 03:55:53', '2025-01-05 03:55:53'),
(3, 'upload/why_studyus_images/1870687982.study3.svg', 'Attractive Class', 'আকর্ষণীয় ক্লাস', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।', '2025-01-05 03:57:17', '2025-01-05 03:57:17'),
(4, 'upload/why_studyus_images/1106157650.study4.svg', '2Female Tutor', '২ মহিলা শিক্ষিকা', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।', '2025-01-05 03:58:38', '2025-01-05 03:58:38'),
(5, 'upload/why_studyus_images/1982761752.study5.svg', 'Worldwide recognition', 'বিশ্বব্যাপী স্বীকৃত', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।', '2025-01-05 04:00:35', '2025-01-05 04:00:35'),
(6, 'upload/why_studyus_images/485955937.study6.svg', 'East Online Payments', 'ইস্ট অনলাইন পেমেন্টস', 'We provide Quran lessons and all of our courses round the clock. Which help you and your kids to learn holy Quran / all courses quickly and smoothly. uu', 'আমরা কুরআন পাঠ এবং আমাদের সমস্ত কোর্স চব্বিশ ঘন্টা প্রদান করি। যা আপনাকে এবং আপনার বাচ্চাদের পবিত্র কুরআন / সমস্ত কোর্স দ্রুত এবং মসৃণভাবে শিখতে সাহায্য করে।', '2025-01-05 04:01:39', '2025-01-05 04:01:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blogs_slug_unique` (`slug`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_orders`
--
ALTER TABLE `book_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courses_slug_unique` (`slug`);

--
-- Indexes for table `course_orders`
--
ALTER TABLE `course_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_orders`
--
ALTER TABLE `package_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_infos`
--
ALTER TABLE `user_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_infos_user_id_foreign` (`user_id`);

--
-- Indexes for table `whystudy_us`
--
ALTER TABLE `whystudy_us`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `book_orders`
--
ALTER TABLE `book_orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `course_orders`
--
ALTER TABLE `course_orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `package_orders`
--
ALTER TABLE `package_orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_infos`
--
ALTER TABLE `user_infos`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `whystudy_us`
--
ALTER TABLE `whystudy_us`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_infos`
--
ALTER TABLE `user_infos`
  ADD CONSTRAINT `user_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
